<CsoundSynthesizer>
<CsOptions>
-odac -d
</CsOptions>
<CsInstruments>
sr = 44100
ksmps = 32
nchnls = 2
0dbfs = 1

gisine ftgen 1, 0, 16384, 10, 1

instr 1
; Default instrument template
ifreq = p4
iamp = p5
aenv linsegr 0, 0.01, 1, 0.1, 0.7, 0.1, 0
asig oscil iamp * aenv, ifreq
outs asig, asig
endin

instr 2
endin

instr 3
endin

instr 4
endin

instr 5
endin

instr 6
endin

instr 7
endin

instr 8
endin

instr 9
endin

instr 10
endin

instr 11
endin

instr 12
endin

instr 13
endin

instr 14
endin

instr 15
endin

instr 16
endin

instr 17
endin

instr 18
endin

instr 19
endin

instr 20
endin

instr 21
endin

instr 22
endin

instr 23
endin

instr 24
endin

instr 25
endin

instr 26
endin

instr 27
endin

instr 28
endin

instr 29
endin

instr 30
endin

instr 31
endin

instr 32
endin

instr 33
endin

instr 34
endin

instr 35
endin

instr 36
endin

instr 37
endin

instr 38
endin

instr 39
endin

instr 40
endin

instr 41
endin

instr 42
endin

instr 43
endin

instr 44
endin

instr 45
endin

instr 46
endin

instr 47
endin

instr 48
endin

instr 49
endin

instr 50
endin

instr 51
endin

instr 52
endin

instr 53
endin

instr 54
endin

instr 55
endin

instr 56
endin

instr 57
endin

instr 58
endin

instr 59
endin

instr 60
endin

instr 61
endin

instr 62
endin

instr 63
endin

instr 64
endin

instr 65
endin

instr 66
endin

instr 67
endin

instr 68
endin

instr 69
endin

instr 70
endin

instr 71
endin

instr 72
endin

instr 73
endin

instr 74
endin

instr 75
endin

instr 76
endin

instr 77
endin

instr 78
endin

instr 79
endin

instr 80
endin

instr 81
endin

instr 82
endin

instr 83
endin

instr 84
endin

instr 85
endin

instr 86
endin

instr 87
endin

instr 88
endin

instr 89
endin

instr 90
endin

instr 91
endin

instr 92
endin

instr 93
endin

instr 94
endin

instr 95
endin

instr 96
endin

instr 97
endin

instr 98
endin

instr 99
endin

instr 100
endin

instr 101
endin

instr 102
endin

instr 103
endin

instr 104
endin

instr 105
endin

instr 106
endin

instr 107
endin

instr 108
endin

instr 109
endin

instr 110
endin

instr 111
endin

instr 112
endin

instr 113
endin

instr 114
endin

instr 115
endin

instr 116
endin

instr 117
endin

instr 118
endin

instr 119
endin

instr 120
endin

instr 121
endin

instr 122
endin

instr 123
endin

instr 124
endin

instr 125
endin

instr 126
endin

instr 127
endin

instr 128
endin
</CsInstruments>
<CsScore>
; Load sample ftables
f 100 0 0 1 "samples/1hihat.wav" 0 0 0

i 1.001 0.0000 0.1250 261.6256 0.5000 0
i 1.002 0.5000 0.1250 261.6256 0.5000 0
i 1.003 1.0000 0.1250 261.6256 0.5000 0
i 1.004 1.5000 0.1250 261.6256 0.5000 0
e
</CsScore>
</CsoundSynthesizer>
